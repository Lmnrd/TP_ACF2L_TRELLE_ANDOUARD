(function () {
	const barreNavigation = document.getElementById('barreNavigation');
	const sectionActivites = document.getElementById('activites');
	if (!barreNavigation || !sectionActivites) return;

	const obtenirDecalage = () => barreNavigation.offsetHeight || 80;

	const mettreAJourBarre = () => {
		const rectangle = sectionActivites.getBoundingClientRect();
		const decalage = obtenirDecalage();
		const aAtteintActivites = rectangle.top <= decalage;
		if (aAtteintActivites) {
			barreNavigation.classList.remove('barre-transparente');
			barreNavigation.classList.add('barre-solide');
		} else {
			barreNavigation.classList.remove('barre-solide');
			barreNavigation.classList.add('barre-transparente');
		}
	};

	let identifiantRaf = null;
	const Defilement = () => {
		if (identifiantRaf !== null) return;
		identifiantRaf = window.requestAnimationFrame(() => {
			identifiantRaf = null;
			mettreAJourBarre();
		});
	};

	window.addEventListener('scroll', Defilement, { passive: true });
	window.addEventListener('resize', Defilement);
	window.addEventListener('load', mettreAJourBarre);
	mettreAJourBarre();
})();
